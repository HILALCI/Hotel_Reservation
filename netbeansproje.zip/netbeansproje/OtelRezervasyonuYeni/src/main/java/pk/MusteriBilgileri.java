
package pk;

public class MusteriBilgileri {
    public static int MusteriID;
    public static String MusteriTC;
    public static String MusteriAdi;
    public static String MusteriSoyadi;
    public static String MusteriTel;
    public static String MusteriMail;
}
